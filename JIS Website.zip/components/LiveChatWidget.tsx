import React from 'react';

// LiveChatWidget removed: stub implementation to avoid build/runtime errors.
// If you want the file deleted instead, remove this file and any imports that reference it.

const LiveChatWidget: React.FC = () => {
	// Intentionally no UI or external API calls.
	return null;
};

export default LiveChatWidget;