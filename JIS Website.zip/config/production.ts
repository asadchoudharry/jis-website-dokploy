export const config = {
    apiBaseUrl: 'https://staging.jis-saudi.comstaging.jis-saudi.com/api',
    uploadsBaseUrl: 'https://staging.jis-saudi.com/uploads',
    imageBaseUrl: 'https://staging.jis-saudi.com/assets/images'
};
