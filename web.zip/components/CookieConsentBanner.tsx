import React from 'react';

// This component is deprecated and has been replaced by CookieManager.tsx.
// It is kept as a valid empty component to prevent potential build errors.
const CookieConsentBanner: React.FC = () => {
  return null;
};

export default CookieConsentBanner;